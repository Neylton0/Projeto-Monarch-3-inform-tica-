import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Flame, Zap, Crown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const ICON_MAP: Record<string, any> = {
  trophy: Trophy,
  star: Star,
  flame: Flame,
  zap: Zap,
  crown: Crown,
};

export default function RecentAchievements() {
  const achievementsQuery = trpc.achievements.list.useQuery();
  const userAchievementsQuery = trpc.achievements.userAchievements.useQuery();

  const achievements = achievementsQuery.data || [];
  const userAchievements = userAchievementsQuery.data || [];

  if (achievementsQuery.isLoading || userAchievementsQuery.isLoading) {
    return (
      <div className="space-y-2">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-16" />
        ))}
      </div>
    );
  }

  // Get recent unlocked achievements (last 3)
  const recentAchievements = userAchievements
    .slice(-3)
    .reverse()
    .map((ua) => achievements.find((a) => a.id === ua.achievementId))
    .filter(Boolean);

  if (recentAchievements.length === 0) {
    return (
      <Card className="p-6 text-center">
        <Trophy className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Nenhuma conquista desbloqueada ainda</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {recentAchievements.map((achievement) => {
        if (!achievement) return null;
        const IconComponent = ICON_MAP[achievement.icon] || Trophy;
        return (
          <Card key={achievement.id} className="p-3 flex items-center gap-3 bg-gradient-to-r from-primary/5 to-accent/5">
            <div className="p-2 bg-primary/10 rounded">
              <IconComponent className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{achievement.name}</p>
              <p className="text-xs text-muted-foreground">{achievement.description}</p>
            </div>
            <Badge className="bg-primary text-primary-foreground text-xs">Nova</Badge>
          </Card>
        );
      })}
    </div>
  );
}
