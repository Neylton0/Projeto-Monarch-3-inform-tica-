import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Moon, Sun, LogOut, Plus, Zap, Trophy, Calendar, BarChart3 } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import TasksList from "@/components/TasksList";
import PomodoroTimer from "@/components/PomodoroTimer";
import AchievementsPanel from "@/components/AchievementsPanel";
import DailyGoalsPanel from "@/components/DailyGoalsPanel";
import RecentAchievements from "@/components/RecentAchievements";
import ProductivityChart from "@/components/ProductivityChart";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch user data
  const userQuery = trpc.user.getProfile.useQuery();
  const statsQuery = trpc.user.getStats.useQuery();

  if (!user) {
    return null;
  }

  const userData = userQuery.data;
  const stats = statsQuery.data;

  // Calculate XP progress percentage
  const xpProgress = userData?.currentXp ? (userData.currentXp / 100) * 100 : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/monarch-logo_15fb455c.png" alt="Monarch" className="h-8 w-8" />
            <h1 className="text-xl font-bold text-primary">Monarch</h1>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              title={theme === "dark" ? "Modo claro" : "Modo escuro"}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={logout}>
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* User Profile Card */}
        <div className="mb-8 grid gap-4 md:grid-cols-3">
          {/* Level & XP Card */}
          <Card className="md:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Nível</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold text-primary">{userData?.level || 1}</div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground mb-2">Experiência</p>
                  <p className="text-lg font-semibold">{userData?.currentXp || 0}/100</p>
                </div>
              </div>
              <Progress value={xpProgress} className="mt-4" />
            </CardContent>
          </Card>

          {/* Stats Overview */}
          <Card className="md:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Estatísticas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="flex flex-col items-center">
                  <div className="text-2xl font-bold text-accent">{stats?.totalTasksCompleted || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Tarefas</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-2xl font-bold text-accent">{stats?.totalPomodorosCompleted || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Pomodoros</p>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-2xl font-bold text-accent">{stats?.currentStreak || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Sequência</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Visão Geral</span>
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Tarefas</span>
            </TabsTrigger>
            <TabsTrigger value="pomodoro" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Pomodoro</span>
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              <span className="hidden sm:inline">Conquistas</span>
            </TabsTrigger>
            <TabsTrigger value="stats" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Estatísticas</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="md:col-span-2">
                <DailyGoalsPanel />
              </div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Trophy className="h-4 w-4" />
                    Conquistas Recentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RecentAchievements />
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Próximas Tarefas</CardTitle>
                <CardDescription>Suas tarefas mais importantes</CardDescription>
              </CardHeader>
              <CardContent>
                <TasksList limit={3} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <CardTitle>Minhas Tarefas</CardTitle>
                <CardDescription>Gerencie suas tarefas diárias</CardDescription>
              </CardHeader>
              <CardContent>
                <TasksList />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pomodoro Tab */}
          <TabsContent value="pomodoro">
            <Card>
              <CardHeader>
                <CardTitle>Temporizador Pomodoro</CardTitle>
                <CardDescription>Mantenha o foco com a técnica Pomodoro</CardDescription>
              </CardHeader>
              <CardContent>
                <PomodoroTimer />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <AchievementsPanel />
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats">
            <ProductivityChart />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
