import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, RotateCcw, CheckCircle } from "lucide-react";
import { toast } from "sonner";

type TimerMode = "focus" | "shortBreak" | "longBreak";

const DURATIONS: Record<TimerMode, number> = {
  focus: 25 * 60,
  shortBreak: 5 * 60,
  longBreak: 15 * 60,
};

export default function PomodoroTimer() {
  const [mode, setMode] = useState<TimerMode>("focus");
  const [timeLeft, setTimeLeft] = useState(DURATIONS.focus);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const createSessionMutation = trpc.pomodoro.create.useMutation();
  const completeSessionMutation = trpc.pomodoro.complete.useMutation();
  const utils = trpc.useUtils();

  // Timer effect
  useEffect(() => {
    if (!isRunning) return;

    intervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsRunning(false);
          handleTimerComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning]);

  const handleTimerComplete = async () => {
    if (mode === "focus") {
      // Complete the Pomodoro session
      if (currentSessionId) {
        try {
          await completeSessionMutation.mutateAsync({ id: currentSessionId });
          await utils.pomodoro.list.invalidate();
          await utils.user.getStats.invalidate();
          await utils.dailyGoals.getToday.invalidate();
        } catch (error) {
          console.error("Error completing session:", error);
        }
      }

      toast.success("Sessão Pomodoro concluída! 🎉");
      setSessionsCompleted((prev) => prev + 1);
      
      // Determine next break
      if ((sessionsCompleted + 1) % 4 === 0) {
        setMode("longBreak");
        setTimeLeft(DURATIONS.longBreak);
      } else {
        setMode("shortBreak");
        setTimeLeft(DURATIONS.shortBreak);
      }
      setCurrentSessionId(null);
    } else if (mode === "shortBreak") {
      toast.info("Pausa curta concluída. Pronto para mais um Pomodoro?");
      setMode("focus");
      setTimeLeft(DURATIONS.focus);
    } else if (mode === "longBreak") {
      toast.info("Pausa longa concluída. Você merece descansar!");
      setMode("focus");
      setTimeLeft(DURATIONS.focus);
      setSessionsCompleted(0);
    }
  };

  const handleStartPause = async () => {
    if (!isRunning && mode === "focus") {
      try {
        const result = await createSessionMutation.mutateAsync({});
        if (result && typeof result === 'object' && 'insertId' in result) {
          setCurrentSessionId((result as any).insertId);
        }
      } catch (error) {
        toast.error("Erro ao criar sessão Pomodoro");
        return;
      }
    }
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(DURATIONS[mode]);
    setCurrentSessionId(null);
  };

  const handleModeChange = (newMode: TimerMode) => {
    setIsRunning(false);
    setMode(newMode);
    setTimeLeft(DURATIONS[newMode]);
    setCurrentSessionId(null);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getModeColor = (m: TimerMode) => {
    switch (m) {
      case "focus":
        return "bg-primary text-primary-foreground";
      case "shortBreak":
        return "bg-green-600 text-white";
      case "longBreak":
        return "bg-blue-600 text-white";
    }
  };

  const getModeLabel = (m: TimerMode) => {
    switch (m) {
      case "focus":
        return "Foco (25 min)";
      case "shortBreak":
        return "Pausa Curta (5 min)";
      case "longBreak":
        return "Pausa Longa (15 min)";
    }
  };

  return (
    <div className="space-y-6">
      {/* Mode Selection */}
      <div className="flex gap-2 justify-center flex-wrap">
        {(["focus", "shortBreak", "longBreak"] as TimerMode[]).map((m) => (
          <Button
            key={m}
            variant={mode === m ? "default" : "outline"}
            onClick={() => handleModeChange(m)}
            disabled={isRunning}
            className={mode === m ? getModeColor(m) : ""}
          >
            {getModeLabel(m)}
          </Button>
        ))}
      </div>

      {/* Timer Display */}
      <Card className="p-12 text-center bg-gradient-to-br from-primary/10 to-accent/10">
        <div className="text-6xl font-bold text-primary font-mono mb-4">
          {formatTime(timeLeft)}
        </div>
        <p className="text-lg text-muted-foreground mb-6">{getModeLabel(mode)}</p>

        {/* Controls */}
        <div className="flex gap-4 justify-center mb-6">
          <Button
            onClick={handleStartPause}
            size="lg"
            className="gap-2 min-w-32"
            disabled={createSessionMutation.isPending}
          >
            {isRunning ? (
              <>
                <Pause className="h-5 w-5" />
                Pausar
              </>
            ) : (
              <>
                <Play className="h-5 w-5" />
                Iniciar
              </>
            )}
          </Button>

          <Button
            onClick={handleReset}
            variant="outline"
            size="lg"
            className="gap-2"
            disabled={isRunning}
          >
            <RotateCcw className="h-5 w-5" />
            Reiniciar
          </Button>
        </div>

        {/* Sessions Completed */}
        <div className="flex items-center justify-center gap-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <span className="text-sm text-muted-foreground">
            {sessionsCompleted} sessão{sessionsCompleted !== 1 ? "s" : ""} concluída{sessionsCompleted !== 1 ? "s" : ""}
          </span>
        </div>
      </Card>

      {/* Tips */}
      <Card className="p-4 bg-accent/5 border-accent/20">
        <p className="text-sm text-muted-foreground">
          💡 <strong>Dica:</strong> Use a técnica Pomodoro para manter o foco. Trabalhe 25 minutos, descanse 5 minutos. Após 4 Pomodoros, faça uma pausa mais longa de 15 minutos.
        </p>
      </Card>
    </div>
  );
}
