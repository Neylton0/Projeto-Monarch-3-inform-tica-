# Projeto Monarch - TODO

## Fase 1: Infraestrutura e Temas
- [x] Configurar paleta de cores roxa (tema claro e escuro) em index.css
- [x] Implementar sistema de tema claro/escuro com ThemeProvider
- [x] Adicionar logo Monarch à interface
- [x] Configurar fontes e tipografia

## Fase 2: Banco de Dados e Schema
- [x] Criar tabela de tarefas (tasks)
- [x] Criar tabela de sessões Pomodoro (pomodoroSessions)
- [x] Criar tabela de metas diárias (dailyGoals)
- [x] Criar tabela de conquistas do usuário (userAchievements)
- [x] Criar tabela de histórico de XP (xpHistory)
- [x] Criar tabela de estatísticas do usuário (userStats)
- [x] Executar migrações do banco de dados

## Fase 3: Lista de Tarefas
- [x] Implementar criação de tarefas com prioridade e categoria
- [x] Implementar edição de tarefas
- [x] Implementar marcação de conclusão de tarefas
- [x] Implementar exclusão de tarefas
- [x] Implementar filtros por prioridade e categoria
- [x] Criar UI para lista de tarefas

## Fase 4: Temporizador Pomodoro
- [x] Implementar lógica do temporizador (25 min foco, 5 min pausa curta, 15 min pausa longa)
- [x] Implementar controles (iniciar, pausar, reiniciar)
- [x] Implementar notificações ao fim de cada ciclo
- [x] Criar UI do temporizador
- [x] Salvar sessões Pomodoro concluídas no banco

## Fase 5: Sistema de XP e Níveis
- [x] Implementar cálculo de XP por tarefa concluída
- [x] Implementar cálculo de XP por sessão Pomodoro
- [x] Implementar sistema de níveis com progressão
- [x] Criar procedimento para atualizar XP e nível
- [x] Criar UI para exibir nível e XP

## Fase 6: Sistema de Conquistas
- [x] Definir lista de conquistas (badges/troféus)
- [x] Implementar lógica de desbloqueio de conquistas
- [x] Criar tabela de conquistas disponíveis
- [x] Implementar verificação de conquistas ao completar ações
- [x] Criar UI para exibir conquistas

## Fase 7: Metas Diárias
- [x] Implementar criação de metas diárias (número de tarefas e pomodoros)
- [x] Implementar progresso em tempo real
- [x] Implementar barra de progresso
- [x] Implementar recompensas ao atingir metas
- [x] Criar UI para metas diárias

## Fase 8: Dashboard Principal
- [x] Criar layout do dashboard
- [x] Exibir visão geral do progresso diário
- [x] Exibir nível atual e XP
- [x] Exibir conquistas recentes
- [x] Exibir estatísticas de produtividade
- [x] Implementar gráficos de histórico

## Fase 9: Testes e Polimento
- [x] Escrever testes unitários (vitest)
- [x] Testar fluxos principais
- [x] Otimizar performance
- [x] Revisar acessibilidade
- [x] Revisar responsividade

## Fase 10: Deploy e Entrega
- [x] Criar checkpoint final
- [x] Preparar documentação
- [x] Entregar projeto ao usuário


## Fase 11: Landing Page
- [x] Criar página inicial pública (Home.tsx)
- [x] Implementar hero section com apresentação
- [x] Adicionar seção de features principais
- [x] Implementar call-to-action para login/cadastro
- [x] Adicionar footer com informações
- [x] Testar responsividade da landing page
