import { eq, and, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, tasks, pomodoroSessions, dailyGoals, achievements, userAchievements, xpHistory, userStats } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== TASKS =====
export async function getUserTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.createdAt));
}

export async function createTask(userId: number, title: string, description?: string, priority?: string, category?: string, xpReward?: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(tasks).values({
    userId,
    title,
    description,
    priority: (priority as any) || "medium",
    category: category || "general",
    xpReward: xpReward || 10,
  });
  return result;
}

export async function updateTask(taskId: number, updates: Record<string, any>) {
  const db = await getDb();
  if (!db) return null;
  return db.update(tasks).set(updates).where(eq(tasks.id, taskId));
}

export async function deleteTask(taskId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(tasks).where(eq(tasks.id, taskId));
}

// ===== POMODORO SESSIONS =====
export async function getUserPomodoroSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pomodoroSessions).where(eq(pomodoroSessions.userId, userId)).orderBy(desc(pomodoroSessions.createdAt));
}

export async function createPomodoroSession(userId: number, taskId?: number, duration?: number, xpReward?: number) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(pomodoroSessions).values({
    userId,
    taskId,
    duration: duration || 25,
    xpReward: xpReward || 25,
  });
}

export async function completePomodoroSession(sessionId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(pomodoroSessions).set({ completed: true, completedAt: new Date() }).where(eq(pomodoroSessions.id, sessionId));
}

// ===== DAILY GOALS =====
export async function getTodayDailyGoal(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const today = new Date().toISOString().split('T')[0];
  const result = await db.select().from(dailyGoals).where(and(eq(dailyGoals.userId, userId), eq(dailyGoals.date, today as any))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createDailyGoal(userId: number, date: string, tasksGoal?: number, pomodorosGoal?: number) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(dailyGoals).values({
    userId,
    date: date as any,
    tasksGoal: tasksGoal || 5,
    pomodorosGoal: pomodorosGoal || 4,
  });
}

export async function updateDailyGoalProgress(goalId: number, tasksCompleted?: number, pomodorosCompleted?: number) {
  const db = await getDb();
  if (!db) return null;
  const updates: Record<string, any> = {};
  if (tasksCompleted !== undefined) updates.tasksCompleted = tasksCompleted;
  if (pomodorosCompleted !== undefined) updates.pomodorosCompleted = pomodorosCompleted;
  return db.update(dailyGoals).set(updates).where(eq(dailyGoals.id, goalId));
}

// ===== XP AND LEVELS =====
export async function addXp(userId: number, xpAmount: number, source: string, sourceId?: number) {
  const db = await getDb();
  if (!db) return null;

  // Add to history
  await db.insert(xpHistory).values({
    userId,
    xpAmount,
    source,
    sourceId,
  });

  // Update user XP
  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (user.length === 0) return null;

  const currentUser = user[0];
  const newTotalXp = (currentUser.totalXp || 0) + xpAmount;
  const newCurrentXp = ((currentUser.currentXp || 0) + xpAmount) % 100;
  let newLevel = currentUser.level || 1;

  if ((currentUser.currentXp || 0) + xpAmount >= 100) {
    newLevel += Math.floor(((currentUser.currentXp || 0) + xpAmount) / 100);
  }

  await db.update(users).set({
    totalXp: newTotalXp,
    currentXp: newCurrentXp,
    level: newLevel,
  }).where(eq(users.id, userId));

  return { newTotalXp, newCurrentXp, newLevel };
}

// ===== ACHIEVEMENTS =====
export async function getAvailableAchievements() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(achievements).orderBy(achievements.id);
}

export async function getUserAchievements(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userAchievements).where(eq(userAchievements.userId, userId));
}

export async function unlockAchievement(userId: number, achievementId: number) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if already unlocked
  const existing = await db.select().from(userAchievements).where(and(eq(userAchievements.userId, userId), eq(userAchievements.achievementId, achievementId))).limit(1);
  if (existing.length > 0) return null;

  return db.insert(userAchievements).values({
    userId,
    achievementId,
  });
}

// ===== USER STATS =====
export async function getUserStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userStats).where(eq(userStats.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createUserStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(userStats).values({ userId });
}

export async function updateUserStats(userId: number, updates: Record<string, any>) {
  const db = await getDb();
  if (!db) return null;
  return db.update(userStats).set(updates).where(eq(userStats.userId, userId));
}

// ===== SEED ACHIEVEMENTS =====
export async function seedAchievements() {
  const db = await getDb();
  if (!db) return;

  const achievementsList = [
    { slug: "first_task", name: "Primeiro Passo", description: "Complete sua primeira tarefa", icon: "star", condition: "1_task_completed" },
    { slug: "task_master_5", name: "Mestre de Tarefas", description: "Complete 5 tarefas", icon: "trophy", condition: "5_tasks_completed" },
    { slug: "task_master_25", name: "Campeão de Tarefas", description: "Complete 25 tarefas", icon: "crown", condition: "25_tasks_completed" },
    { slug: "pomodoro_warrior", name: "Guerreiro Pomodoro", description: "Complete 10 sessões Pomodoro", icon: "flame", condition: "10_pomodoros" },
    { slug: "focus_master", name: "Mestre do Foco", description: "Complete 50 sessões Pomodoro", icon: "zap", condition: "50_pomodoros" },
    { slug: "daily_grind", name: "Rotina Diária", description: "Complete uma meta diária", icon: "calendar", condition: "1_daily_goal" },
    { slug: "streak_7", name: "Semana de Ouro", description: "Mantenha uma sequência de 7 dias", icon: "fire", condition: "7_day_streak" },
    { slug: "level_5", name: "Ascensão", description: "Alcance o nível 5", icon: "arrow-up", condition: "level_5" },
    { slug: "level_10", name: "Lenda", description: "Alcance o nível 10", icon: "star-burst", condition: "level_10" },
  ];

  for (const ach of achievementsList) {
    const existing = await db.select().from(achievements).where(eq(achievements.slug, ach.slug)).limit(1);
    if (existing.length === 0) {
      await db.insert(achievements).values(ach);
    }
  }
}
