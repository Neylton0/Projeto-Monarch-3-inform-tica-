# Monarch - Sistema de Gestão de Tempo com Gamificação

Bem-vindo ao **Monarch**, um aplicativo web de produtividade gamificado que combina gerenciamento de tarefas, técnica Pomodoro e um sistema de progressão por XP, níveis e conquistas para tornar o foco diário mais engajante e motivador.

## 🎯 Funcionalidades Principais

### 📋 Lista de Tarefas
- **Criar tarefas** com título, descrição, prioridade (baixa/média/alta) e categoria (geral/trabalho/pessoal/saúde/aprendizado)
- **Editar tarefas** existentes para atualizar detalhes
- **Marcar como concluída** para ganhar XP e progresso
- **Excluir tarefas** quando não forem mais necessárias
- **Visualizar XP por tarefa** para entender recompensas

### ⏱️ Temporizador Pomodoro
- **Foco (25 minutos)**: Sessão de trabalho concentrado
- **Pausa Curta (5 minutos)**: Descanso rápido entre sessões
- **Pausa Longa (15 minutos)**: Descanso maior após 4 ciclos de foco
- **Controles**: Iniciar, pausar e reiniciar o temporizador
- **Notificações**: Alertas ao fim de cada ciclo
- **Persistência**: Sessões salvas automaticamente no banco

### ⭐ Sistema de XP e Níveis
- **Ganhe XP** ao concluir tarefas e sessões Pomodoro
- **Evolua de nível** a cada 100 XP acumulado
- **Visualize progresso** em barra de XP no dashboard
- **Sem XP duplicado**: Sistema evita recompensas múltiplas pela mesma ação

### 🏆 Conquistas (Badges/Troféus)
- **Desbloqueáveis por marcos**:
  - Primeira tarefa concluída
  - 5, 10, 25, 50 tarefas completadas
  - Primeira sessão Pomodoro
  - 10, 25, 50 Pomodoros completados
  - Atingir nível 5, 10, 20
  - Sequências diárias de 3, 7, 30 dias
- **Painel de conquistas** com desbloqueadas e próximas
- **Badges visuais** com ícones temáticos

### 🎯 Metas Diárias
- **Progresso em tempo real**: Acompanhe tarefas e Pomodoros do dia
- **Barra de progresso**: Visualize quanto falta para completar a meta
- **Recompensas**: Ganhe XP bônus ao completar a meta diária
- **Atualização automática**: Progresso sincroniza ao concluir ações

### 📊 Dashboard Principal
- **Visão geral do dia**: Nível, XP, estatísticas
- **Próximas tarefas**: Acesso rápido às tarefas mais importantes
- **Conquistas recentes**: Últimas 3 conquistas desbloqueadas
- **Gráficos de produtividade**: Histórico de tarefas e Pomodoros
- **Tema claro/escuro**: Alterne entre temas com paleta roxa

## 🎨 Design e Interface

### Paleta de Cores
- **Tema Claro**: Roxo + Branco
- **Tema Escuro**: Roxo + Preto
- **Cor Primária**: Roxo (#a855f7)
- **Cor de Destaque**: Roxo mais claro para acentos

### Logo
O logo Monarch com coroa e relógio integrado está presente no cabeçalho e em toda a interface.

### Responsividade
- **Mobile-first**: Interface otimizada para dispositivos móveis
- **Tablet**: Layout adaptado para telas médias
- **Desktop**: Experiência completa em telas grandes
- **Acessibilidade**: Navegação por teclado e leitores de tela

## 🚀 Como Usar

### Começar
1. Faça login com sua conta Manus
2. Você será redirecionado para o dashboard
3. Comece criando sua primeira tarefa

### Fluxo Típico de Produtividade
1. **Crie uma tarefa** com título e prioridade
2. **Inicie o Pomodoro** para focar por 25 minutos
3. **Ao terminar**, marque a tarefa como concluída
4. **Ganhe XP** e veja seu progresso na meta diária
5. **Desbloqueie conquistas** ao atingir marcos

### Navegação
- **Visão Geral**: Dashboard com resumo do dia
- **Tarefas**: Lista completa de tarefas com CRUD
- **Pomodoro**: Temporizador com controles
- **Conquistas**: Painel de badges desbloqueadas
- **Estatísticas**: Gráficos de produtividade semanal

## 🔧 Arquitetura Técnica

### Stack
- **Frontend**: React 19 + Tailwind CSS 4 + TypeScript
- **Backend**: Express.js + tRPC
- **Banco de Dados**: MySQL/TiDB
- **Autenticação**: Manus OAuth
- **Testes**: Vitest

### Estrutura do Banco de Dados
- **users**: Usuários com autenticação
- **tasks**: Tarefas com prioridade e categoria
- **pomodoroSessions**: Sessões Pomodoro completadas
- **dailyGoals**: Metas diárias com progresso
- **userStats**: Estatísticas agregadas do usuário
- **xpHistory**: Histórico de XP ganho
- **achievements**: Conquistas disponíveis
- **userAchievements**: Conquistas desbloqueadas por usuário

### Routers tRPC
- `tasks.list`, `tasks.create`, `tasks.update`, `tasks.delete`
- `pomodoro.list`, `pomodoro.create`, `pomodoro.complete`
- `dailyGoals.getToday`, `dailyGoals.updateProgress`
- `achievements.list`, `achievements.userAchievements`, `achievements.unlock`
- `user.getProfile`, `user.getStats`

## 📈 Estatísticas e Progresso

### Métricas Rastreadas
- Total de tarefas concluídas
- Total de Pomodoros completados
- Sequência diária (dias consecutivos com meta completa)
- Total de metas diárias completadas
- Nível atual e XP acumulado

### Gráficos
- **Atividade da Semana**: Tarefas vs Pomodoros por dia
- **Resumo Geral**: Total de tarefas, Pomodoros e metas

## 🔐 Segurança e Privacidade

- **Autenticação**: Integrada com Manus OAuth
- **Dados Persistentes**: Todos os dados salvos no banco de dados
- **Proteção**: Routers protegidos com `protectedProcedure`
- **Isolamento**: Cada usuário vê apenas seus dados

## 🎮 Gamificação

### Sistema de Progressão
- **XP**: Ganhe pontos ao concluir tarefas e Pomodoros
- **Níveis**: Evolua a cada 100 XP
- **Conquistas**: Desbloqueie badges ao atingir marcos
- **Sequências**: Mantenha uma sequência diária para bônus

### Motivação
- **Metas Diárias**: Desafio diário com recompensas
- **Progresso Visual**: Barras de progresso em tempo real
- **Reconhecimento**: Conquistas exibidas no dashboard
- **Histórico**: Gráficos mostrando evolução ao longo do tempo

## 📱 Suporte e Feedback

Para reportar bugs ou sugerir melhorias, entre em contato através da plataforma Manus.

## 📝 Licença

Projeto Monarch © 2026. Todos os direitos reservados.

---

**Monarch**: Seu sistema de gestão de tempo gamificado para produtividade máxima! 👑⏱️
