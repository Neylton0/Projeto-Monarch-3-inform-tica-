import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Moon, Sun, CheckCircle, Zap, Trophy, Target, BarChart3, Flame } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location, navigate] = useLocation();

  // Se usuário já está autenticado, redireciona para dashboard
  if (user && location !== "/dashboard") {
    navigate("/dashboard");
    return null;
  }

  if (loading) {
    return null;
  }

  const loginUrl = getLoginUrl();

  const features = [
    {
      icon: CheckCircle,
      title: "Gerenciamento de Tarefas",
      description: "Crie, organize e acompanhe suas tarefas com prioridades e categorias personalizadas.",
    },
    {
      icon: Zap,
      title: "Técnica Pomodoro",
      description: "Sessões de foco de 25 minutos com pausas automáticas para manter a produtividade.",
    },
    {
      icon: Trophy,
      title: "Sistema de Conquistas",
      description: "Desbloqueie badges e troféus ao atingir marcos e manter sequências diárias.",
    },
    {
      icon: Target,
      title: "Metas Diárias",
      description: "Defina metas de tarefas e Pomodoros com progresso em tempo real e recompensas.",
    },
    {
      icon: BarChart3,
      title: "Estatísticas Detalhadas",
      description: "Acompanhe seu progresso com gráficos de produtividade e histórico de atividades.",
    },
    {
      icon: Flame,
      title: "Gamificação Completa",
      description: "Ganhe XP, suba de nível e mantenha sequências para se manter motivado.",
    },
  ];

  const stats = [
    { value: "∞", label: "Tarefas Ilimitadas" },
    { value: "10+", label: "Conquistas" },
    { value: "100%", label: "Gratuito" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/monarch-logo_15fb455c.png" alt="Monarch" className="h-8 w-8" />
            <h1 className="text-xl font-bold text-primary">Monarch</h1>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              title={theme === "dark" ? "Modo claro" : "Modo escuro"}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Button asChild>
              <a href={loginUrl}>Entrar</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-col">
        {/* Hero Section */}
        <section className="container py-20 md:py-32">
          <div className="grid gap-12 md:grid-cols-2 md:gap-8 items-center">
            {/* Left: Text */}
            <div className="space-y-6">
              <div className="space-y-4">
                <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                  Domine seu tempo com <span className="text-primary">Monarch</span>
                </h2>
                <p className="text-lg text-muted-foreground">
                  O sistema de gestão de tempo gamificado que transforma produtividade em diversão. Combine tarefas, Pomodoro e conquistas para manter o foco e alcançar seus objetivos.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild className="bg-primary hover:bg-primary/90">
                <a href={loginUrl}>Começar Agora</a>
              </Button>
                <Button size="lg" variant="outline">
                  Saiba Mais
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                {stats.map((stat, i) => (
                  <div key={i} className="text-center">
                    <p className="text-2xl font-bold text-primary">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Visual */}
            <div className="relative hidden md:flex items-center justify-center">
              <div className="relative w-full aspect-square max-w-md">
                {/* Decorative circles */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl" />
                <div className="absolute inset-8 bg-gradient-to-tr from-primary/10 to-transparent rounded-full blur-2xl" />

                {/* Logo in center */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <img
                    src="/manus-storage/monarch-logo_15fb455c.png"
                    alt="Monarch"
                    className="h-32 w-32 drop-shadow-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="container py-20 md:py-32">
          <div className="space-y-12">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Funcionalidades Principais</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Tudo que você precisa para gerenciar seu tempo e manter a motivação em um único lugar.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {features.map((feature, i) => {
                const Icon = feature.icon;
                return (
                  <Card key={i} className="border border-border hover:border-primary/50 transition-colors">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="container py-20 md:py-32">
          <div className="space-y-12">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Como Funciona</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Três passos simples para começar sua jornada de produtividade gamificada.
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-3">
              {[
                {
                  step: "1",
                  title: "Crie Suas Tarefas",
                  description: "Adicione tarefas com prioridades e categorias. Cada tarefa concluída traz recompensas.",
                },
                {
                  step: "2",
                  title: "Use o Pomodoro",
                  description: "Inicie sessões de foco de 25 minutos. Pausas automáticas mantêm você fresco e produtivo.",
                },
                {
                  step: "3",
                  title: "Ganhe Recompensas",
                  description: "Acumule XP, suba de nível, desbloqueie conquistas e mantenha suas sequências diárias.",
                },
              ].map((item, i) => (
                <div key={i} className="relative">
                  <div className="space-y-4">
                    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary text-primary-foreground font-bold text-lg">
                      {item.step}
                    </div>
                    <h3 className="text-xl font-semibold">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                  {i < 2 && (
                    <div className="hidden md:block absolute top-6 left-full w-8 h-0.5 bg-gradient-to-r from-primary/50 to-transparent" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="container py-20 md:py-32">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 md:p-12 border border-primary/20">
            <div className="grid gap-8 md:grid-cols-2">
              <div className="space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold">Por que escolher Monarch?</h2>
                <div className="space-y-4">
                  {[
                    "Gamificação que mantém você motivado todos os dias",
                    "Interface moderna com tema claro e escuro",
                    "Sincronização automática de progresso",
                    "Sem anúncios, 100% focado em produtividade",
                    "Dados persistentes e seguros",
                    "Fácil de usar, poderoso em funcionalidades",
                  ].map((benefit, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <p className="text-muted-foreground">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-center">
                <div className="relative w-full aspect-square max-w-xs">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-3xl" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Trophy className="h-24 w-24 text-primary/40" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="container py-20 md:py-32">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Pronto para dominar seu tempo?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Junte-se a milhares de usuários que já estão transformando sua produtividade com Monarch.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="bg-primary hover:bg-primary/90">
                <a href={loginUrl}>Começar Gratuitamente</a>
              </Button>
              <Button size="lg" variant="outline">
                Explorar Recursos
              </Button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border bg-muted/50 mt-20">
          <div className="container py-12">
            <div className="grid gap-8 md:grid-cols-4 mb-8">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <img src="/manus-storage/monarch-logo_15fb455c.png" alt="Monarch" className="h-6 w-6" />
                  <span className="font-bold">Monarch</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Seu sistema de gestão de tempo gamificado para produtividade máxima.
                </p>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Produto</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><a href="#" className="hover:text-foreground transition-colors">Funcionalidades</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">Preços</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Empresa</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><a href="#" className="hover:text-foreground transition-colors">Sobre</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">Blog</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">Contato</a></li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Legal</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><a href="#" className="hover:text-foreground transition-colors">Privacidade</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">Termos</a></li>
                  <li><a href="#" className="hover:text-foreground transition-colors">Cookies</a></li>
                </ul>
              </div>
            </div>

            <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground">
              <p>&copy; 2026 Monarch. Todos os direitos reservados.</p>
              <div className="flex gap-6 mt-4 md:mt-0">
                <a href="#" className="hover:text-foreground transition-colors">Twitter</a>
                <a href="#" className="hover:text-foreground transition-colors">GitHub</a>
                <a href="#" className="hover:text-foreground transition-colors">Discord</a>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
