import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Target, Zap } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function DailyGoalsPanel() {
  const dailyGoalQuery = trpc.dailyGoals.getToday.useQuery();
  const goal = dailyGoalQuery.data;

  if (dailyGoalQuery.isLoading) {
    return <Skeleton className="h-64" />;
  }

  if (!goal) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Meta Diária</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Carregando meta diária...</p>
        </CardContent>
      </Card>
    );
  }

  const tasksProgress = Math.min((goal.tasksCompleted / goal.tasksGoal) * 100, 100);
  const pomodorosProgress = Math.min((goal.pomodorosCompleted / goal.pomodorosGoal) * 100, 100);
  const tasksCompleted = goal.tasksCompleted >= goal.tasksGoal;
  const pomodorosCompleted = goal.pomodorosCompleted >= goal.pomodorosGoal;
  const allCompleted = tasksCompleted && pomodorosCompleted;

  return (
    <Card className={allCompleted ? "bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-200 dark:border-green-800" : ""}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Meta Diária
            </CardTitle>
            <CardDescription>
              {new Date().toLocaleDateString("pt-BR", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
            </CardDescription>
          </div>
          {allCompleted && (
            <Badge className="bg-green-600 text-white gap-1">
              <CheckCircle2 className="h-3 w-3" />
              Completa!
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Tasks Progress */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium">Tarefas</label>
            <span className="text-sm text-muted-foreground">
              {goal.tasksCompleted}/{goal.tasksGoal}
            </span>
          </div>
          <Progress value={tasksProgress} className="h-2" />
          <p className="text-xs text-muted-foreground mt-1">
            {tasksCompleted ? "✓ Meta de tarefas atingida!" : `${goal.tasksGoal - goal.tasksCompleted} tarefas restantes`}
          </p>
        </div>

        {/* Pomodoros Progress */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Pomodoros
            </label>
            <span className="text-sm text-muted-foreground">
              {goal.pomodorosCompleted}/{goal.pomodorosGoal}
            </span>
          </div>
          <Progress value={pomodorosProgress} className="h-2" />
          <p className="text-xs text-muted-foreground mt-1">
            {pomodorosCompleted ? "✓ Meta de Pomodoros atingida!" : `${goal.pomodorosGoal - goal.pomodorosCompleted} Pomodoros restantes`}
          </p>
        </div>

        {/* Reward */}
        {allCompleted && (
          <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-sm font-medium text-primary flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Ganhe +{goal.xpReward} XP ao completar a meta!
            </p>
          </div>
        )}

        {/* Overall Progress */}
        <div className="pt-4 border-t border-border">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Progresso Geral</span>
            <span className="text-sm font-semibold text-primary">
              {Math.round((tasksProgress + pomodorosProgress) / 2)}%
            </span>
          </div>
          <Progress value={(tasksProgress + pomodorosProgress) / 2} className="h-2 mt-2" />
        </div>
      </CardContent>
    </Card>
  );
}
