import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProductivityChart() {
  const tasksQuery = trpc.tasks.list.useQuery();
  const pomodoroQuery = trpc.pomodoro.list.useQuery();
  const statsQuery = trpc.user.getStats.useQuery();

  const tasks = tasksQuery.data || [];
  const pomodoros = pomodoroQuery.data || [];
  const stats = statsQuery.data;

  if (tasksQuery.isLoading || pomodoroQuery.isLoading) {
    return <Skeleton className="h-80" />;
  }

  // Prepare data for the last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split('T')[0];
  });

  const chartData = last7Days.map((date) => {
    const dayTasks = tasks.filter(
      (t) => t.completedAt && t.completedAt.toISOString().split('T')[0] === date
    ).length;
    const dayPomodoros = pomodoros.filter(
      (p) => p.completedAt && p.completedAt.toISOString().split('T')[0] === date
    ).length;

    return {
      date: new Date(date).toLocaleDateString("pt-BR", { month: "short", day: "numeric" }),
      tarefas: dayTasks,
      pomodoros: dayPomodoros,
    };
  });

  return (
    <div className="space-y-4">
      {/* Tasks vs Pomodoros */}
      <Card>
        <CardHeader>
          <CardTitle>Atividade da Semana</CardTitle>
          <CardDescription>Tarefas e Pomodoros completados</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="tarefas" fill="#a855f7" name="Tarefas" />
              <Bar dataKey="pomodoros" fill="#06b6d4" name="Pomodoros" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de Tarefas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalTasksCompleted || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Todas as tarefas concluídas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de Pomodoros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalPomodorosCompleted || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Todas as sessões concluídas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Metas Diárias</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalDailyGoalsCompleted || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Metas completadas</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
