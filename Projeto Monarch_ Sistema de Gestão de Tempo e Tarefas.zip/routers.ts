import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ===== USER ROUTES =====
  user: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserByOpenId(ctx.user.openId);
      return user;
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      let stats = await db.getUserStats(ctx.user.id);
      if (!stats) {
        await db.createUserStats(ctx.user.id);
        stats = await db.getUserStats(ctx.user.id);
      }
      return stats;
    }),
  }),

  // ===== TASKS ROUTES =====
  tasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserTasks(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          priority: z.enum(["low", "medium", "high"]).optional(),
          category: z.string().optional(),
          xpReward: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await db.createTask(
          ctx.user.id,
          input.title,
          input.description,
          input.priority,
          input.category,
          input.xpReward
        );
        return result;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          priority: z.enum(["low", "medium", "high"]).optional(),
          category: z.string().optional(),
          completed: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const task = await db.getUserTasks(ctx.user.id);
        const taskExists = task.some(t => t.id === input.id);
        if (!taskExists) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const updates: Record<string, any> = {};
        if (input.title !== undefined) updates.title = input.title;
        if (input.description !== undefined) updates.description = input.description;
        if (input.priority !== undefined) updates.priority = input.priority;
        if (input.category !== undefined) updates.category = input.category;
        if (input.completed !== undefined) {
          updates.completed = input.completed;
          if (input.completed) {
            const taskData = task.find(t => t.id === input.id);
            if (taskData && !taskData.completed) {
              // Only award XP if task was not previously completed
              updates.completedAt = new Date();
              await db.addXp(ctx.user.id, taskData.xpReward, "task", input.id);
              // Update user stats
              const stats = await db.getUserStats(ctx.user.id);
              if (stats) {
                await db.updateUserStats(ctx.user.id, {
                  totalTasksCompleted: (stats.totalTasksCompleted || 0) + 1,
                });
              }
              // Update daily goal progress
              const dailyGoal = await db.getTodayDailyGoal(ctx.user.id);
              if (dailyGoal) {
                await db.updateDailyGoalProgress(dailyGoal.id, dailyGoal.tasksCompleted + 1);
              }
            }
          }
        }

        return db.updateTask(input.id, updates);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const task = await db.getUserTasks(ctx.user.id);
        const taskExists = task.some(t => t.id === input.id);
        if (!taskExists) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return db.deleteTask(input.id);
      }),
  }),

  // ===== POMODORO ROUTES =====
  pomodoro: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserPomodoroSessions(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          taskId: z.number().optional(),
          duration: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await db.createPomodoroSession(ctx.user.id, input.taskId, input.duration);
        return result;
      }),

    complete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const sessions = await db.getUserPomodoroSessions(ctx.user.id);
        const sessionExists = sessions.some(s => s.id === input.id);
        if (!sessionExists) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const session = sessions.find(s => s.id === input.id);
        if (session && !session.completed) {
          await db.completePomodoroSession(input.id);
          // Award XP
          await db.addXp(ctx.user.id, session.xpReward, "pomodoro", input.id);
          // Update stats
          const stats = await db.getUserStats(ctx.user.id);
          if (stats) {
            await db.updateUserStats(ctx.user.id, {
              totalPomodorosCompleted: (stats.totalPomodorosCompleted || 0) + 1,
            });
          }
          // Update daily goal progress
          const dailyGoal = await db.getTodayDailyGoal(ctx.user.id);
          if (dailyGoal) {
            await db.updateDailyGoalProgress(dailyGoal.id, undefined, dailyGoal.pomodorosCompleted + 1);
          }
        }

        return { success: true };
      }),
  }),

  // ===== DAILY GOALS ROUTES =====
  dailyGoals: router({
    getToday: protectedProcedure.query(async ({ ctx }) => {
      let goal = await db.getTodayDailyGoal(ctx.user.id);
      if (!goal) {
        const today = new Date().toISOString().split('T')[0];
        await db.createDailyGoal(ctx.user.id, today);
        goal = await db.getTodayDailyGoal(ctx.user.id);
      }
      return goal;
    }),

    updateProgress: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          tasksCompleted: z.number().optional(),
          pomodorosCompleted: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.updateDailyGoalProgress(input.id, input.tasksCompleted, input.pomodorosCompleted);
      }),
  }),

  // ===== ACHIEVEMENTS ROUTES =====
  achievements: router({
    list: protectedProcedure.query(async () => {
      return db.getAvailableAchievements();
    }),

    userAchievements: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserAchievements(ctx.user.id);
    }),

    unlock: protectedProcedure
      .input(z.object({ achievementId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.unlockAchievement(ctx.user.id, input.achievementId);
      }),
  }),

  // ===== XP ROUTES =====
  xp: router({
    addXp: protectedProcedure
      .input(
        z.object({
          amount: z.number(),
          source: z.string(),
          sourceId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.addXp(ctx.user.id, input.amount, input.source, input.sourceId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
