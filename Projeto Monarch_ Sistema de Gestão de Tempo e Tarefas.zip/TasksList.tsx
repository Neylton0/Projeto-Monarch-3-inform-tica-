import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, AlertCircle, Edit2 } from "lucide-react";
import { toast } from "sonner";
import TaskEditDialog from "./TaskEditDialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface TasksListProps {
  limit?: number;
}

export default function TasksList({ limit }: TasksListProps) {
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskPriority, setNewTaskPriority] = useState("medium");
  const [newTaskCategory, setNewTaskCategory] = useState("general");
  const [editingTask, setEditingTask] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const tasksQuery = trpc.tasks.list.useQuery();
  const createTaskMutation = trpc.tasks.create.useMutation();
  const updateTaskMutation = trpc.tasks.update.useMutation();
  const deleteTaskMutation = trpc.tasks.delete.useMutation();
  const utils = trpc.useUtils();

  const tasks = tasksQuery.data || [];
  const displayedTasks = limit ? tasks.slice(0, limit) : tasks;

  const handleCreateTask = async () => {
    if (!newTaskTitle.trim()) {
      toast.error("Digite um título para a tarefa");
      return;
    }

    try {
      await createTaskMutation.mutateAsync({
        title: newTaskTitle,
        priority: newTaskPriority as any,
        category: newTaskCategory,
      });
      setNewTaskTitle("");
      setNewTaskPriority("medium");
      setNewTaskCategory("general");
      await utils.tasks.list.invalidate();
      toast.success("Tarefa criada com sucesso!");
    } catch (error) {
      toast.error("Erro ao criar tarefa");
    }
  };

  const handleToggleTask = async (taskId: number, completed: boolean) => {
    try {
      await updateTaskMutation.mutateAsync({
        id: taskId,
        completed: !completed,
      });
      await utils.tasks.list.invalidate();
      await utils.user.getStats.invalidate();
      await utils.dailyGoals.getToday.invalidate();
      toast.success(!completed ? "Tarefa concluída! 🎉" : "Tarefa reaberta");
    } catch (error) {
      toast.error("Erro ao atualizar tarefa");
    }
  };

  const handleDeleteTask = async (taskId: number) => {
    try {
      await deleteTaskMutation.mutateAsync({ id: taskId });
      await utils.tasks.list.invalidate();
      toast.success("Tarefa deletada");
    } catch (error) {
      toast.error("Erro ao deletar tarefa");
    }
  };

  const handleEditTask = (task: any) => {
    setEditingTask(task);
    setEditDialogOpen(true);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "Alta";
      case "medium":
        return "Média";
      case "low":
        return "Baixa";
      default:
        return priority;
    }
  };

  return (
    <div className="space-y-4">
      {/* Create Task Form */}
      <div className="space-y-3">
        <div className="flex gap-2">
          <Input
            placeholder="Adicionar nova tarefa..."
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleCreateTask()}
            className="flex-1"
          />
          <Button
            onClick={handleCreateTask}
            disabled={createTaskMutation.isPending}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Adicionar</span>
          </Button>
        </div>

        <div className="flex gap-2">
          <Select value={newTaskPriority} onValueChange={setNewTaskPriority}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Baixa</SelectItem>
              <SelectItem value="medium">Média</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
            </SelectContent>
          </Select>

          <Select value={newTaskCategory} onValueChange={setNewTaskCategory}>
            <SelectTrigger className="flex-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="general">Geral</SelectItem>
              <SelectItem value="work">Trabalho</SelectItem>
              <SelectItem value="personal">Pessoal</SelectItem>
              <SelectItem value="health">Saúde</SelectItem>
              <SelectItem value="learning">Aprendizado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-2">
        {displayedTasks.length === 0 ? (
          <Card className="p-8 text-center">
            <AlertCircle className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">Nenhuma tarefa ainda. Crie uma para começar!</p>
          </Card>
        ) : (
          displayedTasks.map((task) => (
            <Card
              key={task.id}
              className={`p-4 flex items-start gap-3 transition-all ${
                task.completed ? "opacity-60" : ""
              }`}
            >
              <Checkbox
                checked={task.completed}
                onCheckedChange={() => handleToggleTask(task.id, task.completed)}
                className="mt-1"
              />

              <div className="flex-1 min-w-0">
                <p
                  className={`font-medium ${
                    task.completed ? "line-through text-muted-foreground" : ""
                  }`}
                >
                  {task.title}
                </p>
                {task.description && (
                  <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                )}
                <div className="flex gap-2 mt-2 flex-wrap">
                  <Badge variant="outline" className={getPriorityColor(task.priority)}>
                    {getPriorityLabel(task.priority)}
                  </Badge>
                  <Badge variant="outline">{task.category}</Badge>
                  <Badge variant="secondary" className="gap-1">
                    <span className="text-xs">+{task.xpReward} XP</span>
                  </Badge>
                </div>
              </div>

              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleEditTask(task)}
                  disabled={task.completed}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Edit2 className="h-4 w-4" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDeleteTask(task.id)}
                  disabled={deleteTaskMutation.isPending}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      {editingTask && (
        <TaskEditDialog
          task={editingTask}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          onSuccess={() => {
            setEditingTask(null);
          }}
        />
      )}
    </div>
  );
}
