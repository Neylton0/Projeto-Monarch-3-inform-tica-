import { seedAchievements } from "./db";

async function main() {
  console.log("Seeding achievements...");
  try {
    await seedAchievements();
    console.log("✅ Achievements seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding achievements:", error);
    process.exit(1);
  }
}

main();
