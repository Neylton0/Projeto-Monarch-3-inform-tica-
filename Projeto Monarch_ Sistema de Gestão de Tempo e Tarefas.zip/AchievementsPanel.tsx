import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Flame, Zap, Crown, Lock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const ICON_MAP: Record<string, any> = {
  trophy: Trophy,
  star: Star,
  flame: Flame,
  zap: Zap,
  crown: Crown,
};

export default function AchievementsPanel() {
  const achievementsQuery = trpc.achievements.list.useQuery();
  const userAchievementsQuery = trpc.achievements.userAchievements.useQuery();

  const achievements = achievementsQuery.data || [];
  const userAchievements = userAchievementsQuery.data || [];
  const unlockedIds = new Set(userAchievements.map((ua) => ua.achievementId));

  if (achievementsQuery.isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-40" />
        ))}
      </div>
    );
  }

  const unlockedAchievements = achievements.filter((a) => unlockedIds.has(a.id));
  const lockedAchievements = achievements.filter((a) => !unlockedIds.has(a.id));

  return (
    <div className="space-y-6">
      {/* Unlocked Achievements */}
      {unlockedAchievements.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Conquistas Desbloqueadas ({unlockedAchievements.length})
          </h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {unlockedAchievements.map((achievement) => {
              const IconComponent = ICON_MAP[achievement.icon] || Trophy;
              return (
                <Card key={achievement.id} className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-primary/20 rounded-lg">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold">{achievement.name}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                        <Badge className="mt-3 bg-primary text-primary-foreground">Desbloqueada</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Locked Achievements */}
      {lockedAchievements.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Lock className="h-5 w-5 text-muted-foreground" />
            Próximas Conquistas ({lockedAchievements.length})
          </h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {lockedAchievements.map((achievement) => {
              const IconComponent = ICON_MAP[achievement.icon] || Trophy;
              return (
                <Card key={achievement.id} className="opacity-60">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-muted rounded-lg">
                        <IconComponent className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold">{achievement.name}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                        <Badge variant="outline" className="mt-3">
                          Bloqueada
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {achievements.length === 0 && (
        <Card className="p-8 text-center">
          <Trophy className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Nenhuma conquista disponível ainda.</p>
        </Card>
      )}
    </div>
  );
}
